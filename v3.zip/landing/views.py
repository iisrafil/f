from django.shortcuts import render

from landing.models import Site


def landing_home(request):
    site = Site.objects.get()
    context = {
        "site": site,
    }
    return render(request, 'landing/index.html', context)
