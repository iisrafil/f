"""oldageHome URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path

from dashboard.views import dashboard_home, oldage_home, patient_list
from landing.views import landing_home
from oldageHome import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', landing_home, name='landing_home'),
    path('dashboard/home/', dashboard_home, name='dashboard_home'),
    path('dashboard/oldagehomes/', oldage_home, name='oldage_home'),
    path('dashboard/patient-list/', patient_list, name='Patient_list'),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
