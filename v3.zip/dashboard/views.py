from django.shortcuts import render
from landing.models import Site, OldageHome, Patient, Illness


def dashboard_home(request):
    site = Site.objects.get()
    context = {
        "site": site,
    }
    return render(request, 'dashboard/index.html', context)


def oldage_home(request):
    site = Site.objects.get()
    oldagehomes = OldageHome.objects.all()
    context = {
        "site": site,
        "oldagehomes": oldagehomes,
    }
    return render(request, 'dashboard/oldagehome.html', context)


def patient_list(request):
    site = Site.objects.get()
    patients = Patient.objects.all()
    context = {
        "site": site,
        "patients": patients,
    }
    return render(request, 'dashboard/Patient_list.html', context)


def illness_list(request):
    site = Site.objects.get()
    illnesss = Illness.objects.all()
    context = {
        "site": site,
        "illnesss": illnesss,
    }
    return render(request, 'dashboard/Patient_list.html', context)
